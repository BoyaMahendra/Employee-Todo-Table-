import React from 'react'

const Welcome = () => {
  return (
    <div className='welcome'>
        <h1>Welcome Admin Panel</h1>
    </div>
  )
}

export default Welcome